const { PDFDocument } = require('pdf-lib');
const { pdftobuffer } = require('pdftopic');
const pureImage = require('pureimage');
const fs = require('fs');
const path = require('path');

// pdf converter
// 라이브 Pdf를 이미지 pdf로 변환한다.
class PdfConverter {

    // get pdf page count
    async #getPdfPageCount(pdfBuffer) {
        const pdfDoc = await PDFDocument.load(pdfBuffer);
        const totalPages = pdfDoc.getPageCount()
        console.log("total pages = " + totalPages)

        var count = pdfDoc.getPageCount();
        return count;
    }
    // convert pdf to imaged pdf
    // orginPdfBuffer: 원본 pdf buffer
    // callback: 변환된 pdf buffer를 받을 callback 함수
    async convertPdf(orginPdfBuffer, callback, width, height) {

        const pageCount = await this.#getPdfPageCount(orginPdfBuffer);
        const pdf = orginPdfBuffer;

        // create new imaged pdf
        const pdfDoc = await PDFDocument.create();

        // 각 페이지를 순회하면서 pdf를 이미지로 변환한다.
        // 변환된 이미지를 pdfDoc에 추가한다.
        // 884, 1204
        for (var i = 0; i < pageCount; i++) {
            console.log("saving : " + i);
            await pdftobuffer(pdf, i).then((buffer) => {
                console.log("buffer", buffer.length)

                const page = pdfDoc.addPage([width, height]);
                var embedPng = buffer.toString('base64');

                const pngImage = pdfDoc.embedPng(embedPng).then((pngImage) => {
                    console.log("pngImage", pngImage.width, pngImage.height)

                    const pngDims = pngImage.scale(width / height);
                    page.drawImage(pngImage, {
                        x: 0,
                        y: 0,
                        width: width,
                        height: height,


                    })
                });

            });
        }
        // 변환된 pdf buffer를 callback 함수로 전달한다.
        pdfDoc.save().then((pdfBytes) => {
            callback(pdfBytes);
        });

    }

    async drawImage(buffer, ctx, x, y, width, height) {
        // 임시 파일 경로 생성
        const tempFilePath = path.join(__dirname, 'temp.png');

        // Buffer를 파일로 저장
        fs.writeFileSync(tempFilePath, buffer);

        const image = await pureImage.decodePNGFromStream(fs.createReadStream(tempFilePath));
        ctx.drawImage(image, x, y, width, height);
    }



    async convertPdfJpg(orginPdfBuffer, callback, width, height) {
        const pageCount = await this.#getPdfPageCount(orginPdfBuffer);
        const pdf = orginPdfBuffer;

        const me = this;
        // 각 페이지를 순회하면서 pdf를 이미지로 변환한다.

        var pdfArray = [];
        for (var i = 0; i < pageCount; i++) {
            console.log("saving : " + i);
            await pdftobuffer(pdf, i).then((buffer) => {
                var embedPng = buffer;//.toString('base64');

                pdfArray.push(embedPng);


            });
        }
        //////////////////////////////////////////////////
        const scale = 2;
        // pdfArray를 하나의 이미지로 합성
        const canvas = pureImage.make(width * scale, height * pdfArray.length * scale);
        const ctx = canvas.getContext('2d');



        for (var i = 0; i < pdfArray.length; i++) {
            await me.drawImage(pdfArray[i], ctx, 0, i * height * scale, width * scale, height * scale);
        }


        const output = fs.createWriteStream('output.jpg');
        // 캔버스를 PNG 형식으로 인코딩하고 파일에 쓰기
        pureImage.encodeJPEGToStream(canvas, output).then(() => {
            // send output jpg file as buffer to callback function
            const jpg_buffer = fs.readFileSync('output.jpg');
            callback(jpg_buffer);
        });

    }
}

module.exports = PdfConverter;