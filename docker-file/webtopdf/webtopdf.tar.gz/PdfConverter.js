const { PDFDocument } = require('pdf-lib');
const { pdftobuffer } = require('pdftopic');


// pdf converter
// 라이브 Pdf를 이미지 pdf로 변환한다.
class PdfConverter {
  
    // get pdf page count
    async #getPdfPageCount(pdfBuffer) {
            const pdfDoc = await PDFDocument.load(pdfBuffer);
            const totalPages = pdfDoc.getPageCount()

            var count = pdfDoc.getPageCount();
            return count;
    }
    // convert pdf to imaged pdf
    // orginPdfBuffer: 원본 pdf buffer
    // callback: 변환된 pdf buffer를 받을 callback 함수
    async convertPdf(orginPdfBuffer, callback){

        const pageCount =   await this.#getPdfPageCount(orginPdfBuffer);
        const pdf = orginPdfBuffer; 

        // create new imaged pdf
        const pdfDoc = await PDFDocument.create();

        // 각 페이지를 순회하면서 pdf를 이미지로 변환한다.
        // 변환된 이미지를 pdfDoc에 추가한다.
        for(var i = 0; i < pageCount; i++){
            console.log("saving : " + i);
            await pdftobuffer(pdf, i).then((buffer) => {
                const page = pdfDoc.addPage([595.28, 841.89]);
                var embedPng = buffer.toString('base64');
                
                const pngImage = pdfDoc.embedPng(embedPng).then((pngImage) => {
                    // TODO : 1653 -> image width
                    const pngDims = pngImage.scale(595.28 / 1653);
                    page.drawImage(pngImage, {
                        x: 0,
                        y: 0,
                        width: pngDims.width,
                        height: pngDims.height,
                        //scale: 2.0,
            
                    })
                });
                
            });
        }
        // 변환된 pdf buffer를 callback 함수로 전달한다.
        pdfDoc.save().then((pdfBytes) => {
            callback(pdfBytes);
        });

    }   
}

module.exports = PdfConverter;