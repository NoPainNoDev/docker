var express = require('express');
var router = express.Router();
const CDP = require('chrome-remote-interface');
const puppeteer = require('puppeteer');
const fs = require('fs');
const WebToPdf = require('../webToPdf/WebToPDF.js');



/* GET home page. */
router.get('/', function (req, res, next) {
  res.render('index', { title: 'Express' });
});


router.get('/webToImagedPdf.do', async (req, res, next) => {
  let url = req.query.url;
  let mode = req.query.mode;

  if (mode == null || mode == '') {
    mode = 'P';
  }
  console.log('mode : ' + mode)

  if (url == null || url == '') {
    url = 'https://naver.com';
  }
  console.log('url : ' + url);

  // A4 size in pixel : 3508 x 2480 px
  let webToPdf;
  switch (mode) {
    case "L":
      webToPdf = new WebToPdf(1204, 884);
      break;
    case "P":
      webToPdf = new WebToPdf(884, 1204);
      break;
    default:
      webToPdf = new WebToPdf(1204, 884);
  }

  webToPdf.getImagedPdf(url, callback);

  function callback(pdfData) {
    res.contentType("application/pdf");
    res.send(pdfData);
  }
});
router.get('/webToJpg.do', async (req, res, next) => {
  let url = req.query.url;
  let mode = req.query.mode;

  if (mode == null || mode == '') {
    mode = 'P';
  }
  console.log('mode : ' + mode)

  if (url == null || url == '') {
    url = 'https://naver.com';
  }
  console.log('url : ' + url);

  // A4 size in pixel : 3508 x 2480 px
  let webToPdf;
  switch (mode) {
    case "L":
      webToPdf = new WebToPdf(1204, 884);
      break;
    case "P":
      webToPdf = new WebToPdf(884, 1204);
      break;
    default:
      webToPdf = new WebToPdf(1204, 884);
  }

  webToPdf.getImagedJpg(url, callback);

  function callback(pdfData) {
    res.contentType("image/jpeg");

    const currentDate = new Date().toISOString().split('T')[0];

    var fileName = "report_" + currentDate + ".jpg";
    res.header('Content-Disposition', `attachment; filename="${fileName}"`);

    res.send(pdfData);
  }
});

router.get('/webToLivePdf.do', async (req, res, next) => {
  let url = req.query.url;
  let mode = req.query.mode;

  if (mode == null || mode == '') {
    mode = 'P';
  }
  console.log('mode : ' + mode)


  if (url == null || url == '') {
    url = 'https://naver.com';
  }
  console.log('url : ' + url);


  // A4 size in pixel : 3508 x 2480 px
  let webToPdf;
  switch (mode) {
    case "L":
      webToPdf = new WebToPdf(1204, 884);
      break;
    case "P":
      webToPdf = new WebToPdf(884, 1204);
      break;
    default:
      webToPdf = new WebToPdf(1204, 884);
  }


  webToPdf.getLivePdf(url, mode, callback);

  function callback(pdfData) {
    if (pdfData == null) {
      res.status(500).send("can't generate pdf from given url : " + url);
    }
    else {
      res.contentType("application/pdf");
      res.send(pdfData);
    }
  }
});









module.exports = router;
