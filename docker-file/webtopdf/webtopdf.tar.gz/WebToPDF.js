const puppeteer = require('puppeteer');
const fs = require('fs');
const PdfConverter = require('./PdfConverter.js');

class WebToPdf {
  // constructor
  // viewportWidth: 브라우져의 가로 크기
  // viewportHeight: 브라우져의 세로 크기
  // pdfFileName: pdf로 저장할 파일명
  constructor(viewportWidth, viewportHeight, pdfFileName) {
    this.viewportWidth = viewportWidth;
    this.viewportHeight = viewportHeight;
    // temporary pdf file name
    this.pdfFileName = pdfFileName;
  }
  /////////////////////////////////////////////////////////////////////////////////
  // Common method
  // page를 생성하고 초기화한다.
  async #initPage(url) {
    const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
    try {
      const page = await browser.newPage();
      if (url != undefined) {
        console.log("Navigate to ", url);
        // Navigate to the desired URL
        await page.goto(url);
        // Wait for 2 seconds
        await page.waitForTimeout(1000);
        //await page.waitForFunction('document.readyState === "complete"');
        //await page.setViewport({ width: this.viewportWidth, height: this.viewportHeight }); // Set desired viewport size
      }
      return { browser, page };

    }
    catch (error) {

    }
  }
  // get page total height
  async #getPageTotalHeight(page) {
    const totalHeight = await page.evaluate(() => {
      return Promise.resolve(
        Math.max(
          document.documentElement.scrollHeight,
          document.body.scrollHeight,
          document.documentElement.clientHeight
        )
      );
    });

    return totalHeight;
  }

  // ////////////////////////////////////////////////////////////////////////
  // async getImagedPdf(url, callback) {
  //   const { browser, page } = await this.#initPage(url);
  //   // Generate PDF from the page
  //   const pdfBuffer = await page.pdf({
  //     format: 'A4',
  //   });

  //   await browser.close();
  //   await page.waitForTimeout(1000); // Adjust the wait time if needed

  //   const pdfConverter = new PdfConverter();
  //   const convertedPdfBuffer = await pdfConverter.convertPdf(pdfBuffer, callbackConverterPdf);

  //   function callbackConverterPdf(pdfBuffer) {

  //     const buffer = Buffer.from(pdfBuffer.buffer);
  //     console.log("callbackConverterPdf");
  //     callback(buffer);
  //   }

  // }
  // url을 받아서 pdf로 저장한다. live pdf
  // public method
  async getLivePdf(url, mode, callback) {
    try {
      const { browser, page } = await this.#initPage(url);
      // Generate PDF from the page
      var isLandscape = false;
      if (this.viewportWidth > this.viewportHeight) {
        isLandscape = true;
      }
      const pdfBuffer = await page.pdf({
        format: 'A4',
        printBackground: true,
        //landscape: isLandscape
      });

      await browser.close();
      await page.waitForTimeout(1000); // Adjust the wait time if needed

      // send pdf buffer to callback function
      callback(pdfBuffer);

    }
    catch (error) {
      console.error(error.message);
      callback(null);
    }

  }

}

module.exports = WebToPdf;

